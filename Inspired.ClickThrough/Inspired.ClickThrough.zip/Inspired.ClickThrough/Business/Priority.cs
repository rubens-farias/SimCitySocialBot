﻿using System;

namespace Inspired.ClickThrough.Business
{
    public enum Priority
    {
        Lowest  = 0,
        Low     = 1,
        Medium  = 2,
        High    = 3,
        Highest = 4
    }
}
